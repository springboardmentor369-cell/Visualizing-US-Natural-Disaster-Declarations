This folder contains dashboard screenshots.
