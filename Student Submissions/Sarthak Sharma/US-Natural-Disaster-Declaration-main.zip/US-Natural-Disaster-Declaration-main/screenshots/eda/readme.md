This folder contains EDA screenshots.
