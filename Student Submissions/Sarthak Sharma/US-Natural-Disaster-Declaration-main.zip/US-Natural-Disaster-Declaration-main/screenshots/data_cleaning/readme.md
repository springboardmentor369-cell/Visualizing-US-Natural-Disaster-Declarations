This folder contains data cleaning screenshots.
